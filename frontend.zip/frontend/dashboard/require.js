document.write("\
<script type='text/javascript' src='bower_components/AngularJS-Toaster/toaster.min.js'><\/script>\
<script type='text/javascript' src='asset_files/js/angular-route.min.js'><\/script>\
<script type='text/javascript' src='bower_components/moment/min/moment.min.js'><\/script>\
<script type='text/javascript' src='bower_components/angular-moment/angular-moment.min.js'><\/script>\
<script type='text/javascript' src='asset_files/js/angular-cookies.min.js'><\/script>\
<script type='text/javascript' src='bower_components/bootstrap/dist/js/bootstrap.min.js'><\/script>\
<script type='text/javascript' src='bower_components/angular-bootstrap/ui-bootstrap.min.js'><\/script>\
<script type='text/javascript' src='bower_components/angular-bootstrap/ui-bootstrap-tpls.min.js'><\/script>\
<script type='text/javascript' src='bower_components/angular-loading-bar/build/loading-bar.min.js'><\/script>\
<script type='text/javascript' src='bower_components/angular-animate/angular-animate.min.js'><\/script>\
<script type='text/javascript' src='bower_components/angular-rateit/dist/ng-rateit.js'><\/script>\
<script type='text/javascript' src='bower_components/ng-file-upload/ng-file-upload-shim.min.js'><\/script>\
<script type='text/javascript' src='bower_components/ng-file-upload/ng-file-upload.min.js'><\/script>\
<script type='text/javascript' src='app.js'><\/script>\
<script type='text/javascript' src='asset_files/js/services.js'><\/script>\
<script type='text/javascript' src='bower_components/angular-ui-select/dist/select.js'><\/script>\
<script type='text/javascript' src='bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js'><\/script>\
<script type='text/javascript' src='asset_files/js/routes.js'><\/script>\
<script type='text/javascript' src='asset_files/js/functions.js'><\/script>\
<script type='text/javascript' src='asset_files/js/filters.js'><\/script>\
<script type='text/javascript' src='bower_components/oclazyload/dist/ocLazyLoad.min.js'><\/script>\
<script type='text/javascript' src='bower_components/checklist-model/checklist-model.js'><\/script>\
");

//Directives
document.write("\
<script type='text/javascript' src='directives/common/commonTemp.js'><\/script>\
");
